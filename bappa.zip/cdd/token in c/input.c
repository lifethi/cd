#include <stdio.h>  

int main() {
    printf("Numbers!\n");  
    int a = 5;  
    float b = 7; 
                       
    char c = a+b ;
    
    int result = a ^ b;
 
}


