int a = 3 + 4;
int b = 10 - 2;

int d = 8 / 2;