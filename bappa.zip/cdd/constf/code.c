#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINE 256

int is_constant_expr(char *expr, int *result) {
    int a, b;
    char op;

    // Remove whitespace
    char clean[MAX_LINE];
    int j = 0;
    for (int i = 0; expr[i]; i++)
        if (!isspace(expr[i])) clean[j++] = expr[i];
    clean[j] = '\0';

    // Match pattern: <int> <op> <int>
    if (sscanf(clean, "%d%c%d", &a, &op, &b) == 3) {
        switch (op) {
            case '+': *result = a + b; return 1;
            case '-': *result = a - b; return 1;
            case '*': *result = a * b; return 1;
            case '/': if (b != 0) { *result = a / b; return 1; } break;
        }
    }
    return 0;
}

void process_line(char *line) {
    char var[64], expr[MAX_LINE];
    int folded_val;

    // Check for a simple assignment: int var = expression;
    if (sscanf(line, "int %[^=]= %[^\n;];", var, expr) == 2) {
        printf("Expression: %s\n", line);

        if (is_constant_expr(expr, &folded_val)) {
            printf("-> Three Address Code:\n");
            printf("   t1 = %d\n", folded_val);
            printf("   %-10s = t1\n", var);
            printf("-> Optimization Applied: Constant Folding\n\n");
        } else {
            printf("-> No constant folding applied.\n\n");
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input.c>\n", argv[0]);
        return 1;
    }

    FILE *fp = fopen(argv[1], "r");
    if (!fp) {
        perror("Error opening file");
        return 1;
    }

    char line[MAX_LINE];
    printf("____________Constant Folding___________\n\n");

    while (fgets(line, sizeof(line), fp)) {
        process_line(line);
    }

    fclose(fp);
    return 0;
}

