#include <stdio.h>

int main() {
    int a, x;
    x = 4;
    a = 2 + 3 + x;
    return 0;
}
