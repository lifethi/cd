#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX 100

typedef struct {
    char op[5];
    char arg1[10];
    char arg2[10];
    char result[10];
} Quadruple;

Quadruple quads[MAX];
int quadCount = 0;
int tempCount = 1;

int findCommonSubexpression(char *op, char *arg1, char *arg2) {
    for (int i = 0; i < quadCount; i++) {
        if (strcmp(quads[i].op, op) == 0 &&
            strcmp(quads[i].arg1, arg1) == 0 &&
            strcmp(quads[i].arg2, arg2) == 0) {
            return i;
        }
    }
    return -1;
}

char *insertQuadruple(char *op, char *arg1, char *arg2) {
    static char tempVar[10];
    int index = findCommonSubexpression(op, arg1, arg2);
    if (index != -1) {
        printf("Reusing common subexpression %s %s %s -> %s\n",
               arg1, op, arg2, quads[index].result);
        return quads[index].result;
    } else {
        sprintf(tempVar, "t%d", tempCount++);
        strcpy(quads[quadCount].op, op);
        strcpy(quads[quadCount].arg1, arg1);
        strcpy(quads[quadCount].arg2, arg2);
        strcpy(quads[quadCount].result, tempVar);
        printf("Generated: %s = %s %s %s\n", tempVar, arg1, op, arg2);
        quadCount++;
        return quads[quadCount - 1].result;
    }
}

void displayQuadruples() {
    printf("\n--- Optimized Quadruples with CSE ---\n");
    for (int i = 0; i < quadCount; i++) {
        printf("%d: (%s, %s, %s, %s)\n", i,
               quads[i].op, quads[i].arg1, quads[i].arg2, quads[i].result);
    }
}

void trimSemicolon(char *str) {
    int len = strlen(str);
    if (str[len - 1] == ';') {
        str[len - 1] = '\0';  // Remove the semicolon
    }
}

int main() {
    FILE *fp = fopen("input.c", "r");
    if (!fp) {
        printf("Error opening input file.\n");
        return 1;
    }

    char line[100];
    char var[10], a[10], b[10], c[10];

    printf("____________Common Subexpression Elimination___________\n");

    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "=") && strstr(line, "+")) {
            // Modified sscanf format for better handling of the input
            if (sscanf(line, "%s = %s + %s + %s", var, a, b, c) == 4) {
                // Trim spaces and semicolons from operands
                trimSemicolon(a);
                trimSemicolon(b);
                trimSemicolon(c);
                trimSemicolon(var);

                printf("Processed Expression: %s = %s + %s + %s\n", var, a, b, c);

                // First generate t1 = a + b
                char *t1 = insertQuadruple("+", a, b); // 2 + 3
                // Then generate t2 = t1 + c
                char *t2 = insertQuadruple("+", t1, c); // t1 + x
                // Final assignment
                printf("Assignment: %s = %s\n", var, t2);
                break;
            } else {
                printf("Failed to parse expression: %s\n", line);
            }
        }
    }

    fclose(fp);
    displayQuadruples();
    return 0;
}
