#include<stdio.h>
#include <string.h>
#define MAX 100

struct quad{ char op[5],a1[10],a2[10],res[10];};
int isconst(char*s){ for (int i=0 ;s[i];i++) if(s[i]<'0' || s[i]>'9') return 0; return 1;}

int main(){
    struct quad q[MAX];
    char constMap[MAX][10],constVal[MAX][10];
    int n, constcount=0;

    FILE *fp=fopen("input.txt","r");
    if(!fp)return printf("cant open "),1;

    fscanf(fp,"%d",&n);
    for(int i=0;i<n;i++)
        fscanf(fp, "%s %s %s %s", q[i].op,q[i].a1,q[i].a2,q[i].res);
    fclose(fp);

    for(int i=0;i<n;i++){
        for(int j=0;j<constcount;j++){
            if(!strcmp(q[i].a1, constMap[j])) strcpy(q[i].a1,constVal[j]);
            if(!strcmp(q[i].a2, constMap[j])) strcpy(q[i].a2,constVal[j]);
        }
        if(!strcmp(q[i].op, "=") && isconst(q[i].a1)){
            strcpy(constMap[constcount],q[i].res);
            strcpy(constVal[constcount++],q[i].a1);
        }
    }

    printf("after cponstant propagation");
    for(int i=0;i<n;i++)
        printf("\n%s\t%s\t%s\t%s\n",q[i].op,q[i].a1,q[i].a2,q[i].res);
     return 0;
}
