%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex();
void yyerror(const char *s);
int flag = 0;

typedef struct node {
    char name[20];
    struct node *left, *right;
    int val;
} node;

node* createNode(char* name, node* left, node* right, int val);
void printTree(node* root, int level);
%}

%union {
    int val;
    struct node* n;
}

%token <val> NUMBER
%type <n> E ArithmeticExpression
%left '+' '-'
%left '*' '/' '%'

%%

ArithmeticExpression:
    E {
        printf("Valid expression\n");
        printTree($1, 1);
        printf("\nResult = %d\n", $1->val);
        return 0;
    }
;

E:
    E '+' E {
        $$ = createNode("+", $1, $3, $1->val + $3->val);
    }
  | E '-' E {
        $$ = createNode("-", $1, $3, $1->val - $3->val);
    }
  | E '*' E {
        $$ = createNode("*", $1, $3, $1->val * $3->val);
    }
  | E '/' E {
        if ($3->val == 0) {
            yyerror("Division by zero");
            YYABORT;
        }
        $$ = createNode("/", $1, $3, $1->val / $3->val);
    }
  | E '%' E {
        $$ = createNode("%", $1, $3, $1->val % $3->val);
    }
  | '(' E ')' {
        $$ = createNode("()", $2, NULL, $2->val);
    }
  | NUMBER {
        char buf[20];
        sprintf(buf, "%d", $1);
        $$ = createNode(buf, NULL, NULL, $1);
    }
;

%%

node* createNode(char* name, node* left, node* right, int val) {
    node* newNode = (node*)malloc(sizeof(node));
    strcpy(newNode->name, name);
    newNode->left = left;
    newNode->right = right;
    newNode->val = val;
    return newNode;
}

void printTree(node* root, int level) {
    if (!root) return;
    for (int i = 1; i < level; i++) printf("  ");
    printf("|-- %s\n", root->name);
    printTree(root->left, level + 1);
    printTree(root->right, level + 1);
}

int main() {
    printf("Enter any arithmetic expression:\n");
    yyparse();
    if(flag == 0)
        printf("\nEntered arithmetic expression is Valid\n");
    return 0;
}

void yyerror(const char *s) {
    printf("\nError: %s\n", s);
    flag = 1;
}
